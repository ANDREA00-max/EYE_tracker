function bstat=stationaryBBfun(nboot,bootfun,data,sim,L)

%%%%% DESCRIZIONE:
%Funzione che si appoggia su stationaryBB. Presenta input simili a quelli
%della funzione Matlab "bootstrp" (eccetto per "sim" e "L", indispensabili
%per il bootstrap a blocchi) e restituisce in output le nboot stime del
%parametro statistico richiesto.
%
%%%%% INPUTS:
% nboot --> Numero di ricampionamenti bootstrap da effettuare (su cui
%           stimare il/i parametri statistici richiesti.
%
% bootfun --> function handle della funzione da applicare a ciascuna
%             realizzazione della serie ricampionata. Esempi:
%             = @mean --> viene calcolato il valor medio su ogni serie
%                         ricampionata. "bstat" sar� un vettore colonna.
%             = @(x)[mean(x),std(x)] --> vengono calcolate media e
%                                        deviazione standard su ogni serie
%                                        temporale ricampionata. "bstat"
%                                        sar� una matrice di dimensione
%                                        "nboot" righe per 2 colonne. 
%
% data  --> vettore colonna sul quale applicare il bootstrap a blocchi
%           (puo' essere anche una matrice, avente per ogni colonna un
%           segnale e per ogni riga un campione di ciascun segnale da
%           ricampionare separatamente).


% 1. Eseguiamo una prima volta il block-bootstrap per determinare la
%    dimensione di "bstat".
vboot=stationaryBB(data,sim,L);
bstat=bootfun(vboot);
bstatlen=length(bstat); %Contiamo il numero di colonne che avra' l'output.

% 2. Calcoliamo la statistica richiesta per ogni ricampionamento:
bstat=NaN(nboot,bstatlen);
for p=1:nboot
    vboot=stationaryBB(data,sim,L);
    bstat(p,:)=bootfun(vboot);
end



end